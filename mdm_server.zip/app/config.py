class Config:
    DATABASE = 'mdm.db'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///mdm.db'
    SECRET_KEY = 'super-secret'
